# rum-v2 — Homio-style room dashboard (export from live house, 2026-10-02)

Exported from the live instance (dashboard config hash `efb362ac1dba2edb`, 36 views).
Nothing here touches hardware by itself; buttons in the dashboard do switch lights,
heating setpoints, Sonos/Music Assistant and AMX zones when the entities exist.

## Contents

| Path | Goes to on the server |
|---|---|
| `dashboards/rum-v2.yaml` / `.json` | New storage dashboard `rum-v2` → ⋮ → Raw configuration editor → paste YAML |
| `packages/rum_v2.yaml` | `/config/packages/rum_v2.yaml` (5 automations, 3 scripts) |
| `packages/rum_v2_helpers.yaml` | `/config/packages/rum_v2_helpers.yaml` (12 helpers, same ids as live) |
| `www/rooms/*.svg` | `/config/www/rooms/` (room background placeholders) |
| `www/rum-autofocus.js` | `/config/www/rum-autofocus.js` (opens keyboard on ÖNSKEMÅL) |

Requires `homeassistant: packages: !include_dir_named packages` in `configuration.yaml`.

## Install order

1. **HACS frontend cards** (Dashboard → resources are added by HACS):
   button-card, card-mod, Bubble-Card, vertical-stack-in-card,
   mediocre-hass-media-player-cards, lovelace-multiline-text-input-card
   (`faeibson/lovelace-multiline-text-input-card`).
2. **Resource** (Settings → Dashboards → ⋮ → Resources): `/local/rum-autofocus.js?v=1`, type *module*.
3. **Integrations**:
   - Local To-do, list name **Önskemål** → must become `todo.onskemal`.
   - A weather entity named `weather.forecast_home` (Met.no default).
   - Optional: Music Assistant (app + integration) with a player `media_player.1_huvudplan`.
4. Copy `packages/` and `www/` files, then Developer tools → YAML → check config → restart
   (first time, because new `input_*` and packages are loaded).
5. Create dashboard: Settings → Dashboards → Add → "New dashboard from scratch",
   URL `rum-v2`, then Raw configuration editor → paste `dashboards/rum-v2.yaml` → Save.
6. Clear the app/browser cache (Companion App → Debugging → Reset frontend cache).

## Entities the dashboard reads (from the live house)

Not created by this bundle — on the test server these show as unavailable unless mocked:

- Lights `light.<room>_…` and climate `climate.<room>_…` for every room page.
- Sonos: `media_player.1_bad_relax_van0` (Huvudplan), `media_player.2_sovrum`; MA: `media_player.1_huvudplan`, `media_player.2_sovrum_2`.
- AMX: `input_number.amx_output_N_volume`, `input_boolean.amx_output_N_mute`,
  `input_select.amx_output_N_source` for N = 2, 6, 7, 8, 14, 16, 17.

## Notes

- Script ids are `rum_zon_toggle`, `rum_hem_vaningsscen`, `rum_skicka_onskemal` — the dashboard
  calls these entity ids. (On live, the last two have keys `rum_hem_scen` / `rum_onskemal_skicka`
  but were registered under the alias-based ids above; this bundle uses matching keys.)
- Script field selectors are intentionally omitted (empty selectors made HA disable the scripts).
- `rum-textarea-card.js` from live is NOT included (abandoned experiment).
