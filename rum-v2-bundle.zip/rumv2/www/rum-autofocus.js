// rum-autofocus.js — rum-v2: opens the keyboard when ÖNSKEMÅL is tapped.
// Listens in the capture phase (before button-card), focuses an invisible
// input inside the user's tap (so iOS shows the keyboard), then moves focus
// into the Önskemål multiline textarea once the pop-up has rendered.
(function () {
  if (window.__rumAutofocus) return;
  window.__rumAutofocus = true;
  let last = 0;

  const isOnskemal = (e) => {
    const path = e.composedPath ? e.composedPath() : [];
    return path.some((n) => {
      if (!n || n.tagName !== 'BUTTON-CARD') return false;
      const c = n._config || n.config;
      return c && c.name === 'ÖNSKEMÅL';
    });
  };

  const findTextarea = () => {
    const q = [document];
    for (let i = 0; i < 5000 && q.length; i++) {
      const n = q.shift();
      const els = n.querySelectorAll ? n.querySelectorAll('*') : [];
      for (const el of els) {
        if (el.tagName === 'LOVELACE-MULTILINE-TEXT-INPUT-CARD' && el.shadowRoot) {
          const ta = el.shadowRoot.querySelector('textarea');
          if (ta && ta.getBoundingClientRect().height > 0) return ta;
        }
        if (el.shadowRoot) q.push(el.shadowRoot);
      }
    }
    return null;
  };

  const handler = (e) => {
    if (Date.now() - last < 800) return;
    if (!isOnskemal(e)) return;
    last = Date.now();
    const d = document.createElement('input');
    d.setAttribute('aria-hidden', 'true');
    d.setAttribute('tabindex', '-1');
    d.style.cssText = 'position:fixed;top:50%;left:0;width:1px;height:1px;opacity:0;font-size:16px;border:0;padding:0;margin:0;background:transparent;';
    document.body.appendChild(d);
    try { d.focus({ preventScroll: true }); } catch (err) { d.focus(); }
    let tries = 0;
    const tick = () => {
      const t = findTextarea();
      if (t) {
        try { t.focus({ preventScroll: true }); } catch (err) { t.focus(); }
        setTimeout(() => d.remove(), 300);
        return;
      }
      if (++tries < 40) setTimeout(tick, 100);
      else d.remove();
    };
    setTimeout(tick, 150);
  };

  window.addEventListener('touchend', handler, { capture: true, passive: true });
  window.addEventListener('click', handler, { capture: true });
})();
